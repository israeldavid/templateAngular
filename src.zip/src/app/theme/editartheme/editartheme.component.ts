import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editartheme',
  templateUrl: './editartheme.component.html',
  styleUrls: ['./editartheme.component.scss']
})
export class EditarthemeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
