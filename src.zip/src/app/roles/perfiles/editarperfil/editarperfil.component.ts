import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editarperfil',
  templateUrl: './editarperfil.component.html',
  styleUrls: ['./editarperfil.component.scss']
})
export class EditarperfilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
