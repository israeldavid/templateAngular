import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crearperfil',
  templateUrl: './crearperfil.component.html',
  styleUrls: ['./crearperfil.component.scss']
})
export class CrearperfilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
