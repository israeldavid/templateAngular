export interface App {
    empresa:number,
    titulo:string
}
