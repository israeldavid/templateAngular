export interface mensajeFCM {
  headNotification: string;
  bodyNotification: string;
  topic: string;
  idAplicationSend: string;
}