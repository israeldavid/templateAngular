export interface User {
    usuario:string,
    clave:string
}
