import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enviofcmprueba',
  templateUrl: './enviofcmprueba.component.html',
  styleUrls: ['./enviofcmprueba.component.scss']
})
export class EnviofcmpruebaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
