import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editargrupo',
  templateUrl: './editargrupo.component.html',
  styleUrls: ['./editargrupo.component.scss']
})
export class EditargrupoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
