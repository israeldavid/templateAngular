import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multiempresa',
  templateUrl: './multiempresa.component.html',
  styleUrls: ['./multiempresa.component.scss']
})
export class MultiempresaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
